from typing import Union

__all__ = [
    'num',
]

num = Union[int, float]
