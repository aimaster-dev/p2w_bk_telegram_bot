if (!localStorage.getItem('language')) {
    let myVariable = 'en';
    localStorage.setItem('language', myVariable);
}

let defaultLanguage = localStorage.getItem('language');
// document.addEventListener('DOMContentLoaded', function () {

//     let selectElement = document.getElementById('languageSelect');
//     selectElement.value = defaultLanguage;
// });

// Function to change language based on select box value
function changeLanguage(selectedLanguage) {
    fetchTranslations(selectedLanguage); // Fetch translations for other languages
    currentLanguage = selectedLanguage; // Update current language
    localStorage.setItem('language', selectedLanguage);

}

// Function to fetch translations for non-default languages (if needed in the future)
function fetchTranslations(language) {
    fetch('/lang/lang_' + language + '.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Language file not found');
            }
            return response.json();
        })
        .then(data => {
            applyTranslations(data); // Apply translations for non-default languages
        })
        .catch(error => console.error('Error loading language:', error));
}
fetchTranslations(defaultLanguage);


// Function to apply translations to elements marked with data-translate
function applyTranslations(data) {
    const elements = document.querySelectorAll('[data-translate]');
    elements.forEach(element => {
        const keys = element.getAttribute('data-translate').split('.'); // Split nested keys
        let translatedText = data;
        keys.forEach(key => {
            if (key === "select") {
                const elementsChild = document.querySelectorAll('[data-translate-placeholder]');
                elementsChild.forEach(elementChild => {
                    const keysChild = elementChild.getAttribute('data-translate-placeholder').split('.'); 
                    keysChild.forEach(keyChild => {
                        if(elementChild.querySelector('.select2-selection__placeholder')){
                            elementChild.querySelector('.select2-selection__placeholder').innerText = translatedText[key][keyChild];
                        }
                    });
                });            
            }else if (translatedText[key]) {
                element.innerText = translatedText[key];
            } else {
                translatedText = '';
            }
        });
        
    });
}
