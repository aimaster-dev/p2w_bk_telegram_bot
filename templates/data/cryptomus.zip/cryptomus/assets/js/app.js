$(document).ready(function () {
    $('#selectNetwork').select2({
        placeholder: 'Select Network',
        templateResult: formatState,
        templateSelection: formatState,
        escapeMarkup: function (m) { return m; },
        // disabled: true,

    });
    // $('#selectCurrency').select2({
    //     // placeholder: 'Select Currency',
    //     templateResult: formatState,
    //     templateSelection: formatState,
    //     escapeMarkup: function (m) { return m; },


    // });
    // $('#selectCurrency').on('change', function () {
    //     var selectedCurrency = $(this).val();
    //     if (selectedCurrency) {
    //         $('#selectNetwork').prop('disabled', false).trigger('change');
    //     } else {
    //         $('#selectNetwork').prop('disabled', true).val('').trigger('change');
    //     }
    // });
    $('input[name="network"]').on('change', function () {
        var selectedNetwork = $(this).val();
        if (selectedNetwork) {
            $('#btnPay').find('.cashback').remove();
            $('#btnPay').prop('disabled', false).append('<div class="cashback"><span>|</span><span>Cashback</span><span class="cashback-logo"><svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" viewBox="0 0 91 104" fill="currentColor"><path d="M87.71 24.5805L48.2 1.77055C46.42 0.740547 44.2 0.740547 42.41 1.77055L2.9 24.5805C1.11 25.6105 0 27.5305 0 29.6005V75.2206C0 77.2806 1.11 79.2005 2.9 80.2405L42.41 103.051C43.29 103.561 44.29 103.821 45.31 103.821C46.33 103.821 47.33 103.551 48.21 103.051L87.72 80.2405C89.51 79.2105 90.62 77.2906 90.62 75.2206V29.6005C90.62 27.5405 89.51 25.6205 87.72 24.5805H87.71ZM46.2 49.5805C45.65 49.9005 44.96 49.9005 44.41 49.5805L6 27.4105L44.41 5.24055C44.95 4.93055 45.66 4.93055 46.2 5.24055L84.61 27.4105L46.2 49.5805V49.5805ZM42.41 53.0405C42.69 53.2005 42.99 53.3405 43.31 53.4505V98.9305L4.9 76.7705C4.35 76.4505 4 75.8606 4 75.2206V30.8705L42.41 53.0405V53.0405Z" fill="currentColor"></path></svg></span></div>').trigger('change');
        } else {
            $('#btnPay').prop('disabled', true).trigger('change');
        }
    });
    const radioInputs = document.querySelectorAll('input[name="network"]');
    const qrcode = document.getElementById("qrcode");
    const qr = new QRCode(qrcode);

    radioInputs.forEach(input => {
        input.addEventListener('change', function () {
            const labels = document.querySelectorAll('.label-network');
            labels.forEach(label => {
                label.classList.remove('active');
            });

            if (input.checked) {
                const parentLabel = input.closest('.label-network');
                if (parentLabel) {
                    parentLabel.classList.add('active');
                    $('#selectedNetword').text(input.value);
                    $('#walletAddress').text(input.getAttribute('data-address'));
                    qr.makeCode(input.getAttribute('data-address'));

                }
            }
        });
    });


    function formatState(state) {
        if (!state.id) {
            return state.text;
        }
        var imageUrl = $(state.element).data('image');
        if (!imageUrl) {
            return state.text;
        }
        var $state = $(
            '<span><img src="' + imageUrl + '" class="img-flag" /> ' + state.text + '</span>'
        );
        return $state;
    }

    document.addEventListener('click', function (event) {
        var languageList = document.getElementById('languageList');
        var selectLanguage = document.getElementById('selectLanguage');
        var languageIcon = document.getElementById('languageIcon');

        // Kiểm tra khi click vào button hoặc icon
        if (event.target === selectLanguage || event.target === languageIcon) {
            if (languageList.style.display === 'none') {
                languageList.style.display = 'block';
            } else {
                languageList.style.display = 'none';
            }
        } else {
            // Nếu click bên ngoài button hoặc icon, ẩn danh sách ngôn ngữ
            if (!languageList.contains(event.target)) {
                languageList.style.display = 'none';
            }
        }
    });

    // Ngăn sự kiện click của list-language lan ra button
    document.getElementById('languageList').addEventListener('click', function (event) {
        event.stopPropagation();
    });


});



function startCountdown(durationInSeconds) {
    let timeLeft = durationInSeconds;
    const countdownInterval = setInterval(() => {
        const progressCircle = document.querySelector('.progress-ring__circle-progress');
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;

        const minutesStr = String(minutes).padStart(2, '0');
        const secondsStr = String(seconds).padStart(2, '0');

        const countdownDisplay = document.querySelector('.progress-ring__percentage');
        countdownDisplay.textContent = `${minutesStr}:${secondsStr}`;

        const percentage = Math.floor((timeLeft / durationInSeconds) * 100);
        const dashOffset = ((100 - percentage) / 100) * 314;

        progressCircle.style.strokeDashoffset = dashOffset;

        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
        }

        timeLeft--;
    }, 1000);
}
$('#btnPay').on('click', function (e) {
    e.preventDefault();
    $('.step1').css('display', 'none');
    $('.step2').css('display', 'flex');
    startCountdown(10 * 60);

})
function copyToClipboard() {
    text = $('#walletAddress').text();
    const input = document.createElement('input');
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    alert('Copy to clipboard');
}